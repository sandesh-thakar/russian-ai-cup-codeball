set -e

cd /output && python ./Runner.py "$@"