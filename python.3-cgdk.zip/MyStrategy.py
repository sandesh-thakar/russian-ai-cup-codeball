class MyStrategy:
    def act(self, me, rules, game, action):
        pass
    def custom_rendering(self):
        return ""
